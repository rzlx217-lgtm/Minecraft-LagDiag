# Minecraft Lag Diag — APK non-root

Proyek aplikasi Android 11+ untuk merekam Minecraft sambil bermain, lalu berbagi
laporan ZIP dari HP. Tidak membutuhkan Android Studio atau NDK. Menggunakan
Shizuku UserService sebagai agen shell; **bukan injection/mod native Minecraft**.
Tidak meningkatkan FPS langsung dan tidak menghasilkan offsets fungsi.

## Status

- Kode UI, izin Shizuku, perekam, ZIP, dan share tersedia.
- GitHub Actions menyiapkan Java 17, Gradle 8.11.1 dan Android SDK 35,
  lalu menjalankan unit test, lint, dan assembleDebug.
- Belum ada repository GitHub atau build cloud yang dijalankan.
- APK dan integrasi Shizuku/Perfetto belum terverifikasi pada perangkat fisik.
- AIDL berhasil digenerate memakai compiler Android resmi; seluruh kode aplikasi
  berhasil dikompilasi terhadap Android API 35 dan dependency Shizuku/AndroidX.
- Dua unit test konfigurasi trace lulus melalui JUnit. XML proyek juga valid.
  Kompilasi terpisah ini tidak menggantikan assembleDebug, lint, atau tes HP.

## Build menggunakan GitHub

1. Buat repository kosong di GitHub, misalnya `minecraft-lag-diag`.
2. Ekstrak ZIP proyek; isi repository harus berisi `settings.gradle`, `app/`,
   dan `.github/` di root (bukan satu folder pembungkus di atasnya).
3. Dari PowerShell dalam folder proyek:

```powershell
git init
git add .
git commit -m "Add Android lag diagnostics app"
git branch -M main
git remote add origin https://github.com/USERNAME/minecraft-lag-diag.git
git push -u origin main
```

Git akan meminta autentikasi GitHub melalui mekanisme yang tersedia. Ganti URL
dengan repository Anda. Jangan memasukkan token ke source atau workflow.

4. Buka **Actions → Build APK**. Build berjalan otomatis setelah push;
   `Run workflow` juga tersedia.
5. Setelah job berhasil, unduh artifact **MinecraftLagDiag-debug**.
6. Ekstrak artifact; hasilnya `app-debug.apk` yang bisa dipasang di kedua HP.
   Hasil ini APK debug untuk pengujian, tidak memerlukan keystore rilis.

GitHub runner Linux sudah menyediakan Android command-line tools. Workflow
memasang SDK platform/build-tools yang dipakai, sehingga tidak membutuhkan
SDK di laptop Anda. Paket native ABI tidak digunakan oleh aplikasi diagnostik
ini; instalasi game tetap mempunyai ABI sendiri.

Setiap runner dapat menghasilkan debug signing key berbeda. APK dari build
berikutnya mungkin membutuhkan uninstall versi pengujian sebelumnya sebelum
dipasang. Bagikan ZIP laporan lebih dahulu. Signing rilis yang konsisten
belum diatur.

## Cara menggunakan di HP

1. Instal Shizuku dari sumber resmi: https://shizuku.rikka.app/download/
2. Aktifkan Developer options dan Wireless debugging; pair/start Shizuku.
   Android 11+ memungkinkan langkah ini dari HP tanpa laptop. Shizuku perlu
   diaktifkan kembali setelah reboot. Ikuti panduan OEM bila izin dibatasi.
3. Instal APK, lalu tekan **Hubungkan / izinkan Shizuku** dan berikan izin.
4. Isi catatan pengaturan grafis, render/simulation distance, target FPS,
   addon, status charging, dan skenario lag. Pilih 30/60/90 detik.
5. Tekan **Rekam lalu buka Minecraft**. Ada jeda 8 detik untuk beralih ke game.
   Perekam mengambil metadata dan snapshot awal sebelum interval trace.
6. Mainkan dunia/skenario yang hendak diuji, lalu kembali ke aplikasi.
   Tunggu sampai laporan siap, kemudian tekan **Bagikan laporan ZIP**.
7. Kirim ZIP kepada asisten. Rekam skenario sama pada HP teman jika ingin
   membandingkan. Tidak perlu meminjam HP atau menghubungkannya ke laptop.

Tidak ada overlay, upload otomatis, atau izin akses seluruh storage. File ZIP
diberikan melalui FileProvider. Proses perekam Shizuku bertahan ketika UI
berpindah ke game; pembatasan OEM atau Shizuku yang berhenti tetap dapat
menggagalkan rekaman. Jika itu terjadi, status menunjukkan kegagalan/parsial.

## Isi dan batas laporan

Laporan berisi metadata versi Minecraft aktual/model/Android/ABI, trace
penjadwalan CPU/frekuensi yang tersedia/memori, snapshot CPU/memori/thermal/
baterai, serta sampel thread setiap sekitar 10 detik. Waktu sebenarnya disimpan.

FrameTimeline diminta pada Android 12+, tetapi tidak menjamin cakupan rendering
game native/SurfaceView. `gfxinfo` juga bukan FPS game universal. APK tahap ini
belum mengimplementasikan sampling timestamp layer SurfaceFlinger tambahan yang
ada pada collector laptop. Data GPU vendor dan native callstack belum dikumpulkan.
Ini adalah rekaman untuk dianalisis, bukan diagnosis otomatis.

Status `captured_unvalidated` berarti file trace berhasil disalin, bukan semua
track tersedia. Ring buffer 32 MiB dapat hanya menyimpan bagian akhir trace:
periksa waktu dan packet loss dahulu. Battery temperature bukan suhu CPU/GPU;
penurunan frekuensi sendiri bukan bukti throttling.

Perintah diagnostik tetap dan hanya dijalankan atas tindakan pengguna. Tidak
mengekspos API untuk arbitrary shell, dump private data, patch memori, atau
meluncurkan perintah dari catatan pengguna. Trace sistem berisi metadata proses
lain yang berjalan, tanpa tangkapan layar, isi chat, ataupun isi dunia.

Arsip mentah di shell dibersihkan setelah ZIP selesai. Service menyimpan satu
ZIP terakhir; rekaman baru menggantikannya. ZIP yang sudah diekspor tetap berada
di storage privat aplikasi, sampai aplikasi dihapus/data dibersihkan.

## Validasi dan perangkat

Target desain vivo Y21s dan Redmi Note 15 4G, Android 11+. Bukan jaminan seluruh
HP: dukungan Wireless debugging, Shizuku, dan trace data bergantung pada OS/OEM.
Tidak memerlukan kecocokan offsets dengan Minecraft 26.52, sehingga collector
tetap dapat dipakai pada versi game lain dengan package yang sama.

Build tanpa IDE bila SDK/Java/Gradle tersedia:

```text
gradle :app:testDebugUnitTest :app:lintDebug :app:assembleDebug
```

Referensi primer:
- https://shizuku.rikka.app/guide/setup/
- https://github.com/RikkaApps/Shizuku-API
- https://developer.android.com/build/releases/agp-8-9-0-release-notes
- https://perfetto.dev/docs/learning-more/android
- https://perfetto.dev/docs/data-sources/frametimeline
