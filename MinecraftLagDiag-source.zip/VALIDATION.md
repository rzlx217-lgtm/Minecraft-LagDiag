# Validasi 27 September 2026

Lulus lokal:
- XML AndroidManifest dan FileProvider paths diparse tanpa error.
- AIDL IDiagnostics digenerate dengan aidl.exe Android Build Tools 35.0.0.
- Semua Java aplikasi plus stub AIDL dikompilasi dengan javac --release 17,
  memakai android.jar API 35, Shizuku API/Provider 13.1.5, AndroidX Core 1.15.0.
- TraceConfigTest: JUnit 4.13.2, 2 tests passed.

Kompilasi manual menghasilkan 7 warning metadata anotasi AndroidX karena
classpath validasi tidak menyertakan dependency anotasi transitif. Tidak ada
error kompilasi. Gradle akan menyelesaikan dependency transitif saat build penuh.

Belum dijalankan:
- GitHub Actions (repository belum dibuat).
- Gradle assembleDebug/lintDebug.
- Pemasangan APK, izin/binding Shizuku, rekaman Perfetto, dan berbagi ZIP di HP.

Workflow mengerjakan unit test, lint, dan build APK. Jika gagal, unduh artifact
validation-results atau berikan log job agar error dapat diperbaiki.
