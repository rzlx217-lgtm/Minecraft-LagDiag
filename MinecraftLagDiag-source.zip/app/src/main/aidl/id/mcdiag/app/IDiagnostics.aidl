package id.mcdiag.app;
import android.os.ParcelFileDescriptor;
interface IDiagnostics {
    void destroy() = 16777114;
    String startCapture(int seconds, String notes) = 1;
    String getStatus() = 2;
    ParcelFileDescriptor openReport() = 3;
    void cancelCapture() = 4;
}
