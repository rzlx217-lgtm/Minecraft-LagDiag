package id.mcdiag.app;

public final class TraceConfig {
    private TraceConfig() {}
    public static String create(int api, int seconds) {
        if (api < 30 || seconds < 10 || seconds > 120) throw new IllegalArgumentException("Android 11+, 10-120 seconds required");
        String config = "buffers { size_kb: 32768 fill_policy: RING_BUFFER }\n"
            + "duration_ms: " + seconds * 1000 + "\n"
            + "data_sources { config { name: \"linux.ftrace\" ftrace_config {\n"
            + "ftrace_events: \"sched/sched_switch\" ftrace_events: \"sched/sched_waking\"\n"
            + "ftrace_events: \"power/cpu_frequency\" ftrace_events: \"power/cpu_idle\"\n"
            + "ftrace_events: \"ftrace/print\"\n"
            + "atrace_categories: \"gfx\" atrace_categories: \"view\"\n"
            + "atrace_apps: \"com.mojang.minecraftpe\" } } }\n"
            + "data_sources { config { name: \"linux.process_stats\" process_stats_config {\n"
            + "scan_all_processes_on_start: true proc_stats_poll_ms: 1000 } } }\n"
            + "data_sources { config { name: \"linux.sys_stats\" sys_stats_config {\n"
            + "stat_period_ms: 1000 stat_counters: STAT_CPU_TIMES\n"
            + "meminfo_period_ms: 1000 meminfo_counters: MEMINFO_MEM_AVAILABLE\n"
            + "meminfo_counters: MEMINFO_SWAP_FREE } } }\n";
        if (api >= 31) config += "data_sources { config { name: \"android.surfaceflinger.frametimeline\" } }\n";
        return config;
    }
}
