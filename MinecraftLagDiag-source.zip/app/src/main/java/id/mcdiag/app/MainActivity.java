package id.mcdiag.app;

import android.app.Activity;
import android.content.*;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.*;
import android.widget.*;
import androidx.core.content.FileProvider;
import org.json.JSONObject;
import java.io.*;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import rikka.shizuku.Shizuku;

public class MainActivity extends Activity {
    private final Handler handler = new Handler(Looper.getMainLooper());
    private final ExecutorService io = Executors.newSingleThreadExecutor();
    private IDiagnostics service;
    private Shizuku.UserServiceArgs serviceArgs;
    private boolean binding, resumed, polling;
    private TextView status;
    private EditText notes;
    private Spinner duration;
    private Button record, cancel, share;
    private final Shizuku.OnBinderReceivedListener received = () -> handler.post(this::connect);
    private final Shizuku.OnBinderDeadListener dead = () -> handler.post(() -> {
        service = null; binding = false; status.setText("Shizuku terputus. Aktifkan kembali lalu hubungkan.");
        record.setEnabled(false); cancel.setEnabled(false); share.setEnabled(false);
    });
    private final Shizuku.OnRequestPermissionResultListener permission = (code, result) -> {
        if (result == PackageManager.PERMISSION_GRANTED) connect();
        else status.setText("Izin Shizuku diperlukan untuk merekam data sistem.");
    };
    private final ServiceConnection connection = new ServiceConnection() {
        @Override public void onServiceConnected(ComponentName name, IBinder binder) {
            service = IDiagnostics.Stub.asInterface(binder);
            binding = false;
            refresh();
        }
        @Override public void onServiceDisconnected(ComponentName name) {
            service = null; binding = false;
            status.setText("Perekam terputus. Hubungkan kembali Shizuku.");
            record.setEnabled(false); cancel.setEnabled(false); share.setEnabled(false);
        }
    };
    private final Runnable tick = new Runnable() {
        @Override public void run() {
            if (!resumed) return;
            refresh();
            handler.postDelayed(this, 2000);
        }
    };

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        ScrollView scroll = new ScrollView(this);
        LinearLayout layout = new LinearLayout(this);
        layout.setOrientation(LinearLayout.VERTICAL);
        int pad = (int) (24 * getResources().getDisplayMetrics().density);
        layout.setPadding(pad, pad, pad, pad);
        scroll.addView(layout); setContentView(scroll);
        TextView title = new TextView(this); title.setText("Minecraft Lag Diag"); title.setTextSize(26); layout.addView(title);
        TextView intro = new TextView(this);
        intro.setText("Rekam performa saat bermain, lalu bagikan laporan ZIP. Android 11+ dan Shizuku aktif diperlukan. Tidak perlu root atau laptop saat merekam.");
        layout.addView(intro);
        status = new TextView(this); status.setPadding(0, pad, 0, pad); status.setText("Hubungkan Shizuku untuk mulai."); layout.addView(status);
        Button guide = button(layout, "Panduan Shizuku");
        guide.setOnClickListener(v -> startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse("https://shizuku.rikka.app/guide/setup/"))));
        Button connect = button(layout, "Hubungkan / izinkan Shizuku"); connect.setOnClickListener(v -> connect());
        notes = new EditText(this); notes.setHint("Catat render distance, preset grafis, target FPS, addon, dan kapan lag terjadi");
        notes.setMinLines(3); notes.setMaxLines(6); layout.addView(notes);
        duration = new Spinner(this);
        duration.setAdapter(new ArrayAdapter<>(this, android.R.layout.simple_spinner_dropdown_item,
            new String[]{"30 detik", "60 detik", "90 detik"})); duration.setSelection(1); layout.addView(duration);
        record = button(layout, "Rekam lalu buka Minecraft"); record.setEnabled(false);
        record.setOnClickListener(v -> begin());
        cancel = button(layout, "Batalkan rekaman"); cancel.setEnabled(false);
        cancel.setOnClickListener(v -> {
            IDiagnostics remote = service;
            if (remote != null) io.execute(() -> {
                try { remote.cancelCapture(); } catch (Exception e) { showError(e); }
            });
        });
        share = button(layout, "Bagikan laporan ZIP"); share.setEnabled(false); share.setOnClickListener(v -> export());
        TextView limits = new TextView(this); limits.setPadding(0, pad, 0, 0);
        limits.setText("Laporan membantu analisis CPU, memori, dan thermal; tidak otomatis menemukan fungsi penyebab lag. Data frame/GPU dapat terbatas. Trace mencatat nama proses sistem, tanpa layar, chat, atau isi dunia. Tidak ada upload otomatis.");
        layout.addView(limits);
        serviceArgs = new Shizuku.UserServiceArgs(new ComponentName(this, DiagnosticsService.class))
            .daemon(true).processNameSuffix("diagnostics").debuggable(false).version(1);
        Shizuku.addRequestPermissionResultListener(permission);
        Shizuku.addBinderDeadListener(dead);
        Shizuku.addBinderReceivedListenerSticky(received);
    }
    private Button button(LinearLayout layout, String text) {
        Button b = new Button(this); b.setText(text); layout.addView(b); return b;
    }
    private void connect() {
        try {
            if (!Shizuku.pingBinder()) { status.setText("Aktifkan Shizuku melalui Wireless debugging terlebih dahulu."); return; }
            if (Shizuku.isPreV11() || Shizuku.getVersion() < 13) { status.setText("Perbarui Shizuku ke versi 13 atau lebih baru."); return; }
            if (Shizuku.checkSelfPermission() != PackageManager.PERMISSION_GRANTED) {
                if (Shizuku.shouldShowRequestPermissionRationale()) {
                    status.setText("Izinkan Minecraft Lag Diag dari pengaturan aplikasi yang diizinkan di Shizuku.");
                } else Shizuku.requestPermission(1);
                return;
            }
            if (service == null && !binding) {
                binding = true; status.setText("Menghubungkan perekam…");
                Shizuku.bindUserService(serviceArgs, connection);
            } else refresh();
        } catch (Exception e) { binding = false; showError(e); }
    }
    private void begin() {
        IDiagnostics remote = service;
        if (remote == null) { connect(); return; }
        String note = notes.getText().toString();
        int seconds = new int[]{30,60,90}[duration.getSelectedItemPosition()];
        record.setEnabled(false);
        io.execute(() -> {
            try {
                String result = remote.startCapture(seconds, note);
                handler.post(() -> {
                    if (!"OK".equals(result)) { status.setText(result); refresh(); return; }
                    status.setText("Buka dunia Minecraft. Kembali setelah rekaman selesai.");
                    Intent game = getPackageManager().getLaunchIntentForPackage("com.mojang.minecraftpe");
                    if (game != null) startActivity(game);
                    else status.setText("Buka Minecraft secara manual sekarang. Perekaman menunggu 8 detik.");
                });
            } catch (Exception e) { showError(e); }
        });
    }
    private void refresh() {
        IDiagnostics remote = service;
        if (remote == null || polling || io.isShutdown()) return;
        polling = true;
        io.execute(() -> {
            try {
                JSONObject data = new JSONObject(remote.getStatus());
                handler.post(() -> {
                    polling = false;
                    boolean busy = data.optBoolean("busy");
                    status.setText(data.optString("detail") + ("recording".equals(data.optString("state"))
                        ? "\n" + data.optInt("elapsed") + " / " + data.optInt("duration") + " detik" : ""));
                    record.setEnabled(!busy); cancel.setEnabled(busy); share.setEnabled(!busy && data.optBoolean("has_report"));
                });
            } catch (Exception e) { handler.post(() -> { polling = false; service = null; showError(e); }); }
        });
    }
    private void export() {
        IDiagnostics remote = service;
        if (remote == null) return;
        share.setEnabled(false);
        io.execute(() -> {
            try {
                File directory = new File(getFilesDir(), "reports");
                if (!directory.isDirectory() && !directory.mkdirs()) throw new IOException("Tidak bisa membuat direktori laporan");
                File zip = new File(directory, "minecraft-lag-" + System.currentTimeMillis() + ".zip");
                ParcelFileDescriptor fd = remote.openReport();
                if (fd == null) throw new IOException("Laporan belum tersedia");
                try (InputStream in = new ParcelFileDescriptor.AutoCloseInputStream(fd);
                     OutputStream out = new FileOutputStream(zip)) {
                    byte[] buffer = new byte[32768]; int n;
                    while ((n = in.read(buffer)) != -1) out.write(buffer, 0, n);
                }
                handler.post(() -> {
                    Uri uri = FileProvider.getUriForFile(this, getPackageName() + ".reports", zip);
                    Intent send = new Intent(Intent.ACTION_SEND).setType("application/zip")
                        .putExtra(Intent.EXTRA_STREAM, uri).addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
                    send.setClipData(ClipData.newRawUri("Laporan Minecraft", uri));
                    startActivity(Intent.createChooser(send, "Bagikan laporan")); share.setEnabled(true);
                });
            } catch (Exception e) { showError(e); handler.post(() -> share.setEnabled(true)); }
        });
    }
    private void showError(Exception e) {
        handler.post(() -> { if (!isDestroyed()) status.setText("Gagal: " + e.getMessage()); });
    }
    @Override protected void onResume() { super.onResume(); resumed = true; handler.post(tick); }
    @Override protected void onPause() { resumed = false; handler.removeCallbacks(tick); super.onPause(); }
    @Override protected void onDestroy() {
        handler.removeCallbacks(tick);
        Shizuku.removeBinderReceivedListener(received);
        Shizuku.removeBinderDeadListener(dead);
        Shizuku.removeRequestPermissionResultListener(permission);
        // remove=false keeps the bounded recorder alive while Minecraft is foreground.
        try { Shizuku.unbindUserService(serviceArgs, connection, false); } catch (Exception ignored) { }
        io.shutdown(); super.onDestroy();
    }
}
