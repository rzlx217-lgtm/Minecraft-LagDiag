package id.mcdiag.app;

import android.os.Build;
import android.os.ParcelFileDescriptor;
import android.os.SystemClock;
import org.json.JSONArray;
import org.json.JSONObject;
import java.io.*;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.util.UUID;
import java.util.concurrent.TimeUnit;
import java.util.zip.ZipEntry;
import java.util.zip.ZipOutputStream;

/** Runs as Shizuku's shell user. Exposes fixed diagnostics, never arbitrary shell commands. */
public class DiagnosticsService extends IDiagnostics.Stub {
    private static final String GAME = "com.mojang.minecraftpe";
    private volatile boolean busy, cancelled;
    private volatile String state = "idle", detail = "Siap", traceState = "not_started";
    private volatile File report;
    private volatile Process recorder;
    private volatile long captureStarted;
    private volatile int duration;
    private JSONArray commands;
    private File folder;

    public DiagnosticsService() {}

    @Override public synchronized String startCapture(int seconds, String notes) {
        if (busy) return "Perekaman masih berjalan";
        if (seconds < 10 || seconds > 120) return "Durasi harus 10-120 detik";
        if (notes == null || notes.length() > 4000) return "Catatan terlalu panjang";
        busy = true;
        cancelled = false;
        // Only retain the latest shell-side archive. Exported app-side copies remain.
        if (report != null) report.delete();
        report = null;
        state = "preparing";
        detail = "Buka Minecraft; rekaman dimulai setelah 8 detik";
        duration = seconds;
        captureStarted = 0;
        new Thread(() -> capture(seconds, notes), "mcdiag-recorder").start();
        return "OK";
    }

    @Override public String getStatus() {
        try {
            return new JSONObject().put("state", state).put("detail", detail)
                .put("busy", busy).put("duration", duration)
                .put("elapsed", captureStarted == 0 ? 0 : (SystemClock.elapsedRealtime() - captureStarted) / 1000)
                .put("trace_state", traceState).put("has_report", report != null && report.isFile()).toString();
        } catch (Exception e) { return "{}"; }
    }

    @Override public ParcelFileDescriptor openReport() {
        File current = report;
        if (busy || current == null || !current.isFile()) return null;
        try { return ParcelFileDescriptor.open(current, ParcelFileDescriptor.MODE_READ_ONLY); }
        catch (IOException e) { return null; }
    }

    @Override public void cancelCapture() {
        cancelled = true;
        Process p = recorder;
        if (p != null) p.destroy();
    }
    @Override public void destroy() { cancelCapture(); System.exit(0); }

    private void write(String name, String text) throws IOException {
        Files.write(new File(folder, name).toPath(), text.getBytes(StandardCharsets.UTF_8));
    }

    private String run(String name, String... args) throws Exception {
        File output = new File(folder, name);
        long start = SystemClock.elapsedRealtime();
        Process p = new ProcessBuilder(args).redirectErrorStream(true).redirectOutput(output).start();
        boolean done = p.waitFor(6, TimeUnit.SECONDS);
        if (!done) { p.destroyForcibly(); p.waitFor(2, TimeUnit.SECONDS); }
        commands.put(new JSONObject().put("file", name).put("exit", done ? p.exitValue() : -1)
            .put("timed_out", !done).put("args", new JSONArray(args))
            .put("elapsed_ms", SystemClock.elapsedRealtime() - start));
        // Binder never carries dump output; only small metadata is used internally.
        if (output.length() > 131072) return "[saved to file; too large for metadata]";
        return new String(Files.readAllBytes(output.toPath()), StandardCharsets.UTF_8).trim();
    }

    private void snapshot(String prefix) throws Exception {
        run(prefix + "-meminfo.txt", "/system/bin/dumpsys", "meminfo", GAME);
        run(prefix + "-thermal.txt", "/system/bin/dumpsys", "thermalservice");
        run(prefix + "-battery.txt", "/system/bin/dumpsys", "battery");
        run(prefix + "-cpuinfo.txt", "/system/bin/dumpsys", "cpuinfo");
        run(prefix + "-gfxinfo.txt", "/system/bin/dumpsys", "gfxinfo", GAME, "framestats");
    }

    private void capture(int seconds, String notes) {
        folder = null;
        JSONObject metadata = new JSONObject();
        String remote = null;
        File archive = null;
        String failure = null;
        commands = new JSONArray();
        traceState = "not_started";
        try {
            String id = "mcdiag-" + UUID.randomUUID();
            folder = new File("/data/local/tmp", id);
            if (!folder.mkdir()) throw new IOException("Tidak dapat membuat direktori laporan");
            archive = new File("/data/local/tmp", id + ".zip");
            metadata.put("format_version", 1).put("collector", "mcdiag-apk-0.1")
                .put("created_epoch_ms", System.currentTimeMillis()).put("notes", notes)
                .put("duration_seconds", seconds).put("package", GAME);
            // Delay allows switching from this app into the game; no overlay required.
            for (int i = 0; i < 8 && !cancelled; i++) Thread.sleep(1000);
            if (cancelled) throw new IOException("Dibatalkan pengguna");
            String pid = run("initial-pid.txt", "/system/bin/pidof", GAME);
            if (!pid.matches("[0-9]+(?:\\s+[0-9]+)*"))
                throw new IOException("Minecraft belum berjalan. Buka dunia lalu coba kembali.");
            metadata.put("initial_pids", pid);
            JSONObject device = new JSONObject();
            for (String key : new String[]{"ro.product.model", "ro.product.manufacturer", "ro.build.version.release",
                    "ro.build.version.sdk", "ro.product.cpu.abilist", "ro.soc.model"})
                device.put(key, run("property-" + key + ".txt", "/system/bin/getprop", key));
            metadata.put("device", device);
            String packageDump = run("package-tmp.txt", "/system/bin/dumpsys", "package", GAME);
            StringBuilder version = new StringBuilder();
            for (String line : packageDump.split("\n"))
                if (line.contains("versionName=") || line.contains("versionCode=") || line.contains("primaryCpuAbi="))
                    version.append(line.trim()).append('\n');
            metadata.put("game_version", version.toString());
            write("minecraft-version.txt", version.toString());
            // Keep only version metadata instead of the full package dump.
            new File(folder, "package-tmp.txt").delete();
            run("perfetto-capabilities.txt", "/system/bin/perfetto", "--query");
            snapshot("before");
            if (cancelled) throw new IOException("Dibatalkan pengguna");
            String config = TraceConfig.create(Build.VERSION.SDK_INT, seconds);
            write("trace-config.pbtxt", config);
            remote = "/data/misc/perfetto-traces/" + id + ".perfetto-trace";
            recorder = new ProcessBuilder("/system/bin/perfetto", "--txt", "-c", "-", "-o", remote)
                .redirectErrorStream(true).redirectOutput(new File(folder, "perfetto-recorder.txt")).start();
            try (OutputStream stdin = recorder.getOutputStream()) { stdin.write(config.getBytes(StandardCharsets.UTF_8)); }
            captureStarted = SystemClock.elapsedRealtime();
            state = "recording";
            traceState = "recording";
            detail = "Mainkan skenario lag, lalu kembali setelah rekaman selesai";
            JSONArray samples = new JSONArray();
            long nextSample = captureStarted;
            int index = 0;
            while (!cancelled && SystemClock.elapsedRealtime() - captureStarted < seconds * 1000L) {
                if (SystemClock.elapsedRealtime() >= nextSample) {
                    long sampleStart = SystemClock.elapsedRealtime();
                    String current = run("sample-" + index + "-pid.txt", "/system/bin/pidof", GAME);
                    if (current.matches("[0-9]+(?:\\s+[0-9]+)*"))
                        run("sample-" + index + "-threads.txt", "/system/bin/top", "-b", "-n", "1", "-H", "-p", current.replaceAll("\\s+", ","));
                    run("sample-" + index + "-thermal.txt", "/system/bin/dumpsys", "thermalservice");
                    run("sample-" + index + "-battery.txt", "/system/bin/dumpsys", "battery");
                    samples.put(new JSONObject().put("start_ms", sampleStart - captureStarted)
                        .put("end_ms", SystemClock.elapsedRealtime() - captureStarted).put("pids", current));
                    nextSample = SystemClock.elapsedRealtime() + 10000;
                    index++;
                }
                Thread.sleep(200);
            }
            metadata.put("samples", samples);
            state = "packaging";
            detail = "Menyiapkan ZIP";
            boolean finished = recorder.waitFor(15, TimeUnit.SECONDS);
            if (!finished) { recorder.destroyForcibly(); recorder.waitFor(2, TimeUnit.SECONDS); }
            metadata.put("trace_exit", finished ? recorder.exitValue() : -1);
            File trace = new File(remote);
            if (trace.isFile() && trace.length() > 0) {
                Files.copy(trace.toPath(), new File(folder, "game.perfetto-trace").toPath());
                trace.delete();
                traceState = !cancelled && finished && recorder.exitValue() == 0 ? "captured_unvalidated" : "partial";
            } else traceState = "failed";
            if (cancelled) traceState = "cancelled_or_partial";
            snapshot("after");
        } catch (Exception e) {
            failure = e.toString();
            traceState = cancelled ? "cancelled" : "failed_or_partial";
        } finally {
            Process p = recorder;
            if (p != null && p.isAlive()) p.destroy();
            recorder = null;
            try {
                if (folder != null && folder.isDirectory() && archive != null) {
                    metadata.put("trace_state", traceState).put("error", failure == null ? JSONObject.NULL : failure);
                    write("report.json", metadata.toString(2));
                    write("commands.json", commands.toString(2));
                    write("READ-ME.txt", "System diagnostics; bukan diagnosis otomatis atau offsets.\n"
                        + "captured_unvalidated berarti file berhasil disalin, kelengkapan data belum diuji.\n"
                        + "CPU scheduling/memory/thermal tergantung izin OEM; GPU utilisation tidak universal.\n"
                        + "gfxinfo/FrameTimeline belum tentu mencakup rendering Minecraft SurfaceView.\n"
                        + "Battery temperature bukan suhu CPU. Frekuensi turun sendiri bukan bukti throttling.\n"
                        + "Ring buffer 32 MiB bisa hanya menyimpan bagian terakhir; periksa trace loss.\n"
                        + "Trace memuat nama proses/thread sistem, tanpa layar/chat/isi dunia.\n"
                        + "Collector sendiri memiliki overhead; bandingkan skenario dan pengaturan sama.\n");
                    try (ZipOutputStream zip = new ZipOutputStream(new FileOutputStream(archive))) {
                        File[] files = folder.listFiles();
                        if (files == null) throw new IOException("Tidak bisa membaca direktori laporan");
                        byte[] buffer = new byte[32768];
                        for (File file : files) {
                            if (!file.isFile()) continue;
                            zip.putNextEntry(new ZipEntry(file.getName()));
                            try (InputStream in = new FileInputStream(file)) {
                                int n; while ((n = in.read(buffer)) != -1) zip.write(buffer, 0, n);
                            }
                            zip.closeEntry();
                        }
                    }
                    // Raw files are redundant after a successful ZIP; delete this run's files only.
                    File[] rawFiles = folder.listFiles();
                    if (rawFiles != null) for (File file : rawFiles) if (file.isFile()) file.delete();
                    folder.delete();
                    report = archive;
                    detail = failure == null ? "Laporan siap: " + traceState : "Laporan parsial: " + failure;
                    state = "complete";
                } else { state = "error"; detail = failure == null ? "Laporan gagal" : failure; }
            } catch (Exception e) { state = "error"; detail = "ZIP gagal: " + e; }
            busy = false;
        }
    }
}
