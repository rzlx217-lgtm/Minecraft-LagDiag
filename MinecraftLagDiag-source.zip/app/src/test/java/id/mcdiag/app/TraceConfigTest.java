package id.mcdiag.app;
import org.junit.Test;
import static org.junit.Assert.*;
public class TraceConfigTest {
    @Test public void olderDeviceDoesNotRequestFrameTimeline() {
        assertFalse(TraceConfig.create(30, 60).contains("frametimeline"));
        assertTrue(TraceConfig.create(31, 60).contains("frametimeline"));
        assertTrue(TraceConfig.create(30, 60).contains("duration_ms: 60000"));
    }
    @Test public void rejectUnboundedCapture() {
        for (int seconds : new int[]{-1, 0, 9, 121}) {
            try { TraceConfig.create(35, seconds); fail(); }
            catch (IllegalArgumentException expected) { }
        }
    }
}
